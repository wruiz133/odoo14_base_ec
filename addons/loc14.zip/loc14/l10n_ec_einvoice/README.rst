.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

=======================
Documentos Electrónicos
=======================

Módulo para generación de documentos electrónicos.

* Facturas
* Retenciones


Desarrollado por
----------------

* Cristian Salamea <cristian.salamea@ayni.com.ec>

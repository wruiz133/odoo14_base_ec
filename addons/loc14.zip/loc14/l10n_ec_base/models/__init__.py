# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_tax
from . import account_tax_group
from . import l10n_latam_document_type
from . import res_company
from . import res_partner
from . import account_move

# -*- coding: utf-8 -*-

CODE701 = u'Error en fecha de retención. Tiene 5 días desde la fecha de factura para aplicar una retención.'  # noqa
CODE702 = u'El número no es de 9 dígitos y/o no pertenece a la autorización seleccionada.'  # noqa
CODE703 = u'Retención conciliada con la factura, no se puede anular.'

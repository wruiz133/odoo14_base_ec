.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

========================
Retenciones para Ecuador
========================

Este módulo implementa los documentos de retención para Ecuador.
Personaliza el cálculo de impuestos.

Modulo para gestion de:

    * retenciones
    * Exportar ATS
    * liquidaciones de compra
    * codigos para formularios 103 y 104
    * Impreso de asiento contable
    * Impuesto a la Renta
    * Impuesto al valor agregado
